#!/bin/bash

# 使用方法:  ./run_pipeline.sh de3ef9a3c6a88f46a7e97ad1d065f150
YOUR_ACCESS_KEY=$1

# 导出API密钥为环境变量
export YOUR_ACCESS_KEY

# 运行各个R脚本
Rscript product_scraping.R
Rscript weatherstack_api.R
Rscript etl.R
Rscript run_ootd_api.R &

# 等待API启动
sleep 5

# 调用 /ootd 端点
curl "http://localhost:8000/ootd" --output ootd_plot.png
echo "Outfit of the Day plot saved as ootd_plot.png"