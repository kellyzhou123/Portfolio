library(httr)
library(jsonlite)

# Authentication credentials for WeatherStack API
auth_token <- "059d921b86685ea5b303e023c440d214"

# Function to fetch atmospheric conditions
fetch_atmosphere_data <- function(location) {
  # Configure API endpoint and parameters
  base_endpoint <- "http://api.weatherstack.com/current"
  query_params <- list(
    access_key = auth_token,
    query = location,
    units = "m"  # Explicitly specify metric units
  )
  
  # Execute API request
  api_result <- GET(
    url = base_endpoint,
    query = query_params
  )
  
  # Parse response data
  atmosphere_info <- api_result %>%
    content(as = "text") %>%
    fromJSON(flatten = TRUE)
  
  return(atmosphere_info)
}

# Execute data collection
try({
  # Retrieve atmospheric data for specified location
  atmosphere_info <- fetch_atmosphere_data("London")
  
  # Extract and process relevant metrics
  if (!is.null(atmosphere_info$current)) {
    # Extract key measurements
    temp_now <- atmosphere_info$current$temperature
    condition_text <- atmosphere_info$current$weather_descriptions
    
    # Display current conditions
    message(sprintf("London's current temperature: %s°C", temp_now))
    message(sprintf("Atmospheric conditions: %s", 
                    paste(condition_text, collapse = ", ")))
    
    # Persist data for future analysis
    saveRDS(atmosphere_info, "atmosphere_data.rds")
  } else {
    warning("Data retrieval unsuccessful - verify API response integrity")
  }
})