library(rvest)
library(httr)

# Define categories and URLs 
categories <- list(
  shoes = "https://www.marksandspencer.com/l/women/footwear#intid=gnav_Women_Footwear_All-Footwear",
  short = "https://www.marksandspencer.com/search?searchTerm=t+shirt&intid=normal&langId=-24&storeId=10151&catalogId=10051&searchType=normal",
  long = "https://www.marksandspencer.com/search?searchTerm=long+sleeve+t+shirt&intid=normal&langId=-24&storeId=10151&catalogId=10051&filter=Categories%3DSC_Level_1_1&searchType=categoryTypeAhead",
  jacket = "https://www.marksandspencer.com/search?searchTerm=ladies+jackets&intid=normal&langId=-24&storeId=10151&catalogId=10051&searchType=normal",
  accessories_umb = "https://www.marksandspencer.com/search?intid=normal&langId=-24&storeId=10151&catalogId=10051&searchType=categoryTypeAhead&searchTerm=umbrella",
  accessories_glass = "https://www.marksandspencer.com/search?searchTerm=womens+sunglasses&intid=normal&langId=-24&storeId=10151&catalogId=10051&searchType=normal",
  accessories_bag = "https://www.marksandspencer.com/l/women/handbags#intid=gnav_Women_Accessories_Handbags-and-Purses"
)

# Create images folder
if (!dir.exists("images")) {
  dir.create("images")
}

# Main scraping function
scrape_category <- function(url, category) {
  web_session <- html_session(
    url,
    user_agent("Mozilla/5.0")
  )
  
  if (http_status(web_session$response)$category == "Success") {
    webpage <- web_session %>% read_html()
    
    # Extract product names and images using updated class
    item_names <- webpage %>% 
      html_nodes(".product-card_title__gA6_B") %>% 
      html_text(trim = TRUE)
    
    item_images <- webpage %>% 
      html_nodes(".image-with-sizing_image__p4cYU") %>% 
      html_attr("src")
    
    # Get first 10 items
    item_names <- head(item_names, 10)
    item_images <- head(item_images, 10)
    
    # Process valid products
    valid_products <- data.frame(
      name = character(),
      image_path = character(),
      stringsAsFactors = FALSE
    )
    
    for (i in seq_along(item_images)) {
      if (!is.na(item_images[i]) && nchar(item_images[i]) > 0) {
        timestamp <- format(Sys.time(), "%H%M%S")
        random_string <- paste0(sample(letters, 5, replace=TRUE), collapse="")
        clean_name <- paste0(
          gsub("[^a-zA-Z0-9]", "_", category),
          "_",
          gsub("[^a-zA-Z0-9]", "_", item_names[i]),
          "_",
          timestamp,
          "_",
          random_string,
          "_",
          i
        )
        file_path <- paste0("images/", clean_name, ".jpg")
        download.file(item_images[i], destfile = file_path, mode = "wb")
        
        valid_products <- rbind(valid_products,
                                data.frame(
                                  name = item_names[i],
                                  image_path = file_path,
                                  stringsAsFactors = FALSE
                                ))
      }
    }
    
    valid_products$category <- category
    return(valid_products)
  } else {
    warning(paste("Failed to access:", url))
    return(data.frame(name = NA, category = category, image_path = NA))
  }
}

# Execute scraping
all_products <- do.call(rbind, lapply(names(categories), function(cat) {
  print(paste("Scraping:", cat))
  result <- scrape_category(categories[[cat]], cat)
  if (nrow(result) > 0) {
    return(result)
  } else {
    NULL
  }
}))

# Save results
if (exists("all_products") && nrow(all_products) > 0) {
  write.csv(all_products, "products_raw.csv", row.names = FALSE)
  print(paste("Total products scraped:", nrow(all_products)))
  print(table(all_products$category))
} else {
  message("No data available to save.")
}