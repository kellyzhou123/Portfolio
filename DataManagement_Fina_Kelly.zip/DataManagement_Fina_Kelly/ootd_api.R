library(plumber)
library(DBI)
library(RSQLite)
library(jsonlite)
library(magick)

#* @apiTitle Daily Style Assistant API

#* Get Daily Style Recommendation
#* @get /daily_style
function() {
  # Debug flag
  DEBUG <- TRUE
  
  debug_print <- function(...) {
    if(DEBUG) print(paste0("DEBUG: ", ...))
  }
  
  # Retrieve atmospheric data
  atmosphere_info <- readRDS("atmosphere_data.rds")
  temp_now <- atmosphere_info$current$temperature
  condition_text <- atmosphere_info$current$weather_descriptions
  
  debug_print("Temperature: ", temp_now)
  debug_print("Weather: ", paste(condition_text, collapse=", "))
  
  # Initialize database connection
  db <- dbConnect(SQLite(), dbname = "closet.db")
  
  # Debug: Print all categories
  debug_print("Available categories:")
  print(dbGetQuery(db, "SELECT DISTINCT category FROM closet"))
  
  # Prepare ensemble container
  ensemble <- list()
  
  # Style selection logic based on temperature
  if (temp_now > 28) {
    debug_print("Hot weather outfit selection")
    ensemble$upper <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'short' ORDER BY RANDOM() LIMIT 1")
    ensemble$lower <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'shoes' ORDER BY RANDOM() LIMIT 1")
  } else if (temp_now >= 20 && temp_now <= 28) {
    debug_print("Warm weather outfit selection")
    ensemble$upper <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'short' ORDER BY RANDOM() LIMIT 1")
    ensemble$lower <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'shoes' ORDER BY RANDOM() LIMIT 1")
  } else if (temp_now >= 10 && temp_now < 20) {
    debug_print("Mild weather outfit selection")
    ensemble$upper <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'long' ORDER BY RANDOM() LIMIT 1")
    ensemble$lower <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'shoes' ORDER BY RANDOM() LIMIT 1")
  } else {
    debug_print("Cold weather outfit selection")
    ensemble$upper <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'long' ORDER BY RANDOM() LIMIT 1")
    ensemble$lower <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'shoes' ORDER BY RANDOM() LIMIT 1")
    ensemble$outer <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'jacket' ORDER BY RANDOM() LIMIT 1")
  }
  
  # Print selected items for debugging
  for(item in names(ensemble)) {
    debug_print(paste("Selected", item, ":", ensemble[[item]]$name))
    debug_print(paste("Image path for", item, ":", ensemble[[item]]$image_path))
    debug_print(paste("File exists:", file.exists(ensemble[[item]]$image_path)))
  }
  
  # Weather-specific accessory selection
  weather_conditions <- tolower(condition_text)
  if (any(grepl("rain|drizzle|shower", weather_conditions))) {
    ensemble$add_on <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'accessories_umb' ORDER BY RANDOM() LIMIT 1")
  } else if (any(grepl("sun|clear|bright", weather_conditions))) {
    ensemble$add_on <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'accessories_glass' ORDER BY RANDOM() LIMIT 1")
  } else {
    ensemble$add_on <- dbGetQuery(db, "SELECT * FROM closet WHERE category = 'accessories_bag' ORDER BY RANDOM() LIMIT 1")
  }
  
  # Close database connection
  dbDisconnect(db)
  
  # Enhanced image processing with error handling
  tryCatch({
    style_images <- list()
    valid_images <- list()
    
    # Create a default blank image first
    blank <- image_blank(width = 300, height = 300, color = "white")
    debug_print("Created blank image successfully")
    
    # Load and validate images with detailed error checking
    for (component in names(ensemble)) {
      debug_print(paste("Processing component:", component))
      
      if (!is.null(ensemble[[component]]) && 
          nrow(ensemble[[component]]) > 0 && 
          !is.null(ensemble[[component]]$image_path)) {
        
        image_path <- ensemble[[component]]$image_path
        debug_print(paste("Checking image path:", image_path))
        
        if (file.exists(image_path)) {
          debug_print("File exists, attempting to read...")
          
          # Try to read the image
          img <- try({
            image_read(image_path)
          }, silent = TRUE)
          
          if (!inherits(img, "try-error")) {
            debug_print("Successfully read image")
            valid_images[[component]] <- image_resize(img, "300x300")
          } else {
            debug_print(paste("Failed to read image:", img))
            valid_images[[component]] <- blank
          }
        } else {
          debug_print("File does not exist, using blank image")
          valid_images[[component]] <- blank
        }
      } else {
        debug_print("Invalid component data, using blank image")
        valid_images[[component]] <- blank
      }
    }
    
    # Create header with weather info
    header_canvas <- image_blank(width = 900, height = 80, color = "lavender")
    debug_print("Created header canvas")
    
    # Add weather information with styled text
    header_canvas <- image_annotate(header_canvas, 
                                    format(Sys.Date(), "%B %d, %Y"), 
                                    location = "+30+30",
                                    size = 20, 
                                    color = "navy",
                                    font = "Helvetica")
    
    header_canvas <- image_annotate(header_canvas,
                                    sprintf("Temperature: %d°C", temp_now),
                                    location = "+300+30",
                                    size = 20,
                                    color = "navy",
                                    font = "Helvetica")
    
    header_canvas <- image_annotate(header_canvas,
                                    sprintf("Conditions: %s", paste(condition_text, collapse = ", ")),
                                    location = "+600+30",
                                    size = 20,
                                    color = "navy",
                                    font = "Helvetica")
    
    debug_print("Added text to header")
    
    # Ensure each row has at least one image
    row1 <- valid_images$upper %||% blank
    row2 <- valid_images$lower %||% blank
    
    # Create third row with proper null checking
    row3_images <- c(valid_images$outer %||% blank, 
                     valid_images$add_on %||% blank)
    row3 <- image_append(row3_images, stack = FALSE)
    
    debug_print("Created all rows")
    
    # Combine all elements
    final_image <- image_append(c(header_canvas, row1, row2, row3), stack = TRUE)
    debug_print("Combined final image")
    
    # Add border
    final_image <- image_border(final_image, "lavender", "10x10")
    
    # Save result
    image_write(final_image, path = "daily_style_recommendation.png", format = "png")
    debug_print("Saved final image")
    
    return("ootd_plot.png")
    
  }, error = function(e) {
    print(paste("Error in image processing:", e$message))
    stop("Failed to process images. Please check if all image files exist and are valid.")
  })
}

#* Retrieve Complete Wardrobe Inventory
#* @get /inventory
function() {
  db <- dbConnect(SQLite(), dbname = "closet.db")
  inventory <- dbGetQuery(db, "SELECT * FROM closet")
  dbDisconnect(db)
  return(toJSON(inventory, pretty = TRUE))
}