library(RSQLite)
library(dplyr)

# Data import and validation function
validate_product_data <- function(file_path) {
  tryCatch({
    # Import raw data
    raw_data <- read.csv(file_path, stringsAsFactors = FALSE)
    
    # Enhanced data cleaning with validation
    validated_data <- raw_data %>%
      # Remove invalid entries
      filter(!is.na(name), !is.na(category), !is.na(image_path)) %>%
      # Verify image paths exist
      filter(file.exists(image_path)) %>%
      # Remove any duplicate entries
      distinct() %>%
      # Ensure consistent text formatting
      mutate(
        name = trimws(name),
        category = trimws(category),
        image_path = trimws(image_path)
      )
    
    return(validated_data)
  }, error = function(e) {
    stop("Data validation failed: ", e$message)
  })
}

# Database initialization function
initialize_closet_db <- function(data) {
  tryCatch({
    # Establish database connection
    db_conn <- dbConnect(SQLite(), "closet.db")
    
    # Create table with constraints
    dbExecute(db_conn, "
            CREATE TABLE IF NOT EXISTS closet (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT CHECK(name IS NOT NULL AND trim(name) != ''),
                category TEXT CHECK(category IS NOT NULL AND trim(category) != ''),
                image_path TEXT CHECK(image_path IS NOT NULL AND trim(image_path) != '')
            )
        ")
    
    # Clear existing data
    dbExecute(db_conn, "DELETE FROM closet")
    
    # Insert validated data
    dbWriteTable(db_conn, "closet", data, append = TRUE, row.names = FALSE)
    
    # Verify data insertion
    record_count <- dbGetQuery(db_conn, "SELECT COUNT(*) as count FROM closet")
    category_summary <- dbGetQuery(db_conn, "
            SELECT category, COUNT(*) as items 
            FROM closet 
            GROUP BY category 
            ORDER BY items DESC
        ")
    
    # Display results
    message("Database initialization completed successfully")
    message(sprintf("Total records: %d", record_count$count))
    message("\nItems per category:")
    print(category_summary)
    
    # Cleanup
    dbDisconnect(db_conn)
    
  }, error = function(e) {
    message("Database initialization failed: ", e$message)
    if(exists("db_conn") && dbIsValid(db_conn)) {
      dbDisconnect(db_conn)
    }
  })
}

# Execute the entire process
main <- function() {
  message("Starting database initialization process...")
  
  # Step 1: Validate data
  message("Validating product data...")
  valid_products <- validate_product_data("products_raw.csv")
  
  # Step 2: Initialize database
  message("\nInitializing database...")
  initialize_closet_db(valid_products)
}

# Run the initialization
main()