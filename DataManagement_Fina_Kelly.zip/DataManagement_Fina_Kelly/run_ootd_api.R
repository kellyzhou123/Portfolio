library(plumber)

# load api
r <- plumb("ootd_api.R")
r$run(port = 8000)
