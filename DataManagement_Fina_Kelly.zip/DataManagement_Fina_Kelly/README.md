# Writing the updated README content to a Markdown file
new_readme_content = """
# Daily Style Recommendation System (Atmosphere Style RecSys)

## Project Overview
This project automates the recommendation of daily outfits based on atmospheric and weather conditions. The system involves web scraping, ETL processes, database management, weather data integration, and API development. The recommendation logic applies predefined weather-based rules to select outfits.

---

## Table of Contents
1. [Prerequisites](#prerequisites)
2. [Installation and Setup](#installation-and-setup)
3. [Project Structure](#project-structure)
4. [How to Run](#how-to-run)
5. [Recommendation Logic](#recommendation-logic)
6. [Output Details](#output-details)
7. [Troubleshooting](#troubleshooting)
8. [Contact Information](#contact-information)

---

## Prerequisites
- **Software**:
  - R (≥ 4.0.0)
  - SQLite
  - Bash shell
- **R Packages**:
  Install the required R packages using:
  ```R
  install.packages(c("rvest", "httr", "jsonlite", "DBI", "RSQLite", "plumber", "dplyr", "magick"))
  ```
- **System Dependencies**:
  - `curl` for HTTP requests in the Bash script.

---

## Installation and Setup
1. Clone or download the project repository.
2. Ensure the following directory structure is in place:
   - `images/`: Stores downloaded product images.
3. **API Key Setup**:
   - Obtain an API key from [Weatherstack](https://weatherstack.com/).
   - Export your API key as an environment variable:
     ```bash
     export YOUR_ACCESS_KEY=<Your_API_Key>
     ```

---

## Project Structure
| **File/Folder**               | **Description**                                                                                 |
|--------------------------------|-----------------------------------------------------------------------------------------------|
| `product_scraping.R`           | Scrapes clothing product details from an online retailer.                                      |
| `etl.R`                        | Cleans scraped data and stores it in a SQLite database (`closet.db`).                          |
| `weatherstack_api.R`           | Fetches weather data from the Weatherstack API.                                                |
| `ootd_api.R`                   | Defines API endpoints for outfit recommendations (`/ootd`) and data retrieval (`/rawdata`).    |
| `run_ootd_api.R`               | Starts the API server using Plumber.                                                           |
| `run_pipeline` (Bash script)   | Automates the pipeline including scraping, weather data retrieval, and API execution.          |
| `closet.db`                    | SQLite database containing cleaned product data.                                               |
| `atmosphere_data.rds`          | Stores weather data retrieved from the Weatherstack API.                                       |
| `daily_style_recommendation.png` | Output image generated from `/ootd` API containing outfit suggestions.                        |
| `products_raw.csv`             | Raw product data scraped from the retailer website.                                            |

---

## How to Run
### Run Full Pipeline
Execute the complete automated pipeline with the following command:
```bash
./run_pipeline YOUR_ACCESS_KEY
```

### Start API Server Independently
Run the API server manually:
```bash
Rscript run_ootd_api.R
```

### API Endpoints
- **`/ootd`**: Generates an outfit recommendation and saves it as an image (`daily_style_recommendation.png`).
  ```bash
  curl "http://localhost:8000/ootd" --output daily_style_recommendation.png
  ```
- **`/rawdata`**: Returns all product data in JSON format.
  ```bash
  curl "http://localhost:8000/rawdata"
  ```

---

## Recommendation Logic
- **Rules for Outfit Selection**:
  - **Temperature > 25°C**: Light clothing (e.g., t-shirts, shorts, sandals).
  - **15°C - 25°C**: Comfortable clothing (e.g., long-sleeve tops, jeans, sneakers).
  - **Temperature < 15°C**: Warm clothing (e.g., jackets, sweaters, boots).
  - **Rain Forecast**: Adds a raincoat or umbrella to the recommendation.
  - **Sunny Forecast**: Includes sunglasses as an accessory.
  
Outfit combinations are derived from `closet.db` based on these rules.

---

## Output Details
- **Generated Image**:
  - Name: `daily_style_recommendation.png`
  - Contains:
    - Weather details (date, temperature, condition)
    - Recommended outfit (top, bottom, shoes, outerwear, and accessories).
- **Database**: The SQLite database `closet.db` contains all processed clothing items.

---

## Troubleshooting
1. **Missing API Key**:
   - Ensure `YOUR_ACCESS_KEY` is set as an environment variable.
   - Pass the API key explicitly in the command line if needed.
2. **Port Conflicts**:
   - Ensure port `8000` is available before running the API server.
3. **Missing Dependencies**:
   - Verify all required R packages are installed.
4. **Script Execution Errors**:
   - Check individual logs for each R script in case of errors.

---

# Save the content to a markdown file
file_path_new = "/mnt/data/Daily_Style_Recommendation_README.md"
with open(file_path_new, "w") as file:
    file.write(new_readme_content)

file_path_new